package com.sapient.cartservice.resource;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.sapient.cartservice.model.Product;

public class CartServiceResourceTest {

	private CartServiceResource cartServiceResource;

	@BeforeClass
	public void beforeClass() {
		cartServiceResource = new CartServiceResource(null);
	}

	@DataProvider
	public Object[][] dataProvider() {

		Product discountedProduct1 = new Product("Book1", 100, 1, 2);
		Product discountedProduct2 = new Product("Book2", 50, 1, 1);
		Product discountedProduct3 = new Product("Book3", 100, 1, 3);
		Product discountedProduct4 = new Product("Book4", 150, 1, 1);
		Product discountedProduct5 = new Product("Book5", 250, 1, 1);
		Product zeroQtyProduct1 = new Product("Book2", 50, 1, 0);
		Product zeroQtyProduct2 = new Product("Book4", 150, 1, 0);
		Product normalProduct1 = new Product("Book6", 200, 0, 1);
		Product normalProduct2 = new Product("Book7", 300, 0, 1);

		// Data for one discounted Product in Cart with no discount
		List<Product> list1 = new ArrayList<Product>();
		list1.add(discountedProduct1);

		// Data for 5% discount testcase
		List<Product> list2 = new ArrayList<Product>();
		list2.add(discountedProduct1);
		list2.add(discountedProduct2);

		// Data for 10% discount testcase
		List<Product> list3 = new ArrayList<Product>();
		list3.addAll(list2);
		list3.add(discountedProduct3);

		// Data for 20% discount testcase
		List<Product> list4 = new ArrayList<Product>();
		list4.addAll(list3);
		list4.add(discountedProduct4);

		// Data for 25% discount testcase
		List<Product> list5 = new ArrayList<Product>();
		list5.addAll(list4);
		list5.add(discountedProduct5);

		// Data for zero discount without any discounted products
		List<Product> list6 = new ArrayList<Product>();
		list6.add(normalProduct1);
		list6.add(normalProduct2);

		// Data for zero quantity discounted products
		List<Product> list7 = new ArrayList<Product>();
		list7.addAll(list3);
		list7.add(zeroQtyProduct1);

		List<Product> list8 = new ArrayList<Product>();
		list8.addAll(list4);
		list8.add(zeroQtyProduct1);
		list8.add(zeroQtyProduct2);

		return new Object[][] { new Object[] { list1, 0.0 }, new Object[] { list2, 0.05 }, new Object[] { list3, 0.1 },
				new Object[] { list4, 0.2 }, new Object[] { list5, 0.25 }, new Object[] { list6, 0.0 },
				new Object[] { list7, 0.1 }, new Object[] { list8, 0.2 } };
	}

	@Test(dataProvider = "dataProvider")
	public void getDiscount(List<Product> productList, double expectedDiscount) {
		double discount = cartServiceResource.getDiscount(productList);
		Assert.assertEquals(discount, expectedDiscount);
	}

	@Test(dataProvider = "dataProvider")
	public void setDiscountedPrice(List<Product> selectedList, double discount) {
		cartServiceResource.setDiscountedPrice(selectedList, discount);
		for(Product product: selectedList){
			int price = product.getPrice();
			int quantity = product.getQuantity();
			double discountedPrice = (price - (price * discount)) * quantity;
			Assert.assertEquals(discountedPrice, product.getDiscountedPrice());
		}
	}
}
