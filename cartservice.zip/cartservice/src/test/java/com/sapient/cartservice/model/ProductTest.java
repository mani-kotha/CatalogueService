package com.sapient.cartservice.model;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ProductTest {

	@DataProvider
	public Object[][] dp() {

		Product product1 = new Product();
		
		Product product2 = new Product("ProductName", 100, 1, 10);
		return new Object[][] { new Object[] { product1,true }, new Object[] { product2,false }, };
	}

	@Test(dataProvider = "dp")
	public void Product(Product product,boolean isDefaultConstructor) {
		if(isDefaultConstructor){
			Assert.assertEquals(product.getProductName(), null);
			Assert.assertEquals(product.getPrice(), 0);
			Assert.assertEquals(product.getIsDiscounted(), 0);
			Assert.assertEquals(product.getQuantity(), 0);
		}
		else {
			Assert.assertEquals(product.getProductName(), "ProductName");
			Assert.assertEquals(product.getPrice(), 100);
			Assert.assertEquals(product.getIsDiscounted(), 1);
			Assert.assertEquals(product.getQuantity(), 10);
		}
	}
}
