package com.sapient.cartservice.dao;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.sapient.cartservice.model.Product;

public class CartServiceDaoTest {

	private CartServiceDao cartServiceDao;
	
	@BeforeClass
	public void beforeClass() {
		cartServiceDao = new CartServiceDao();
	}

	@Test
	public void getProducts() {
		List<Product> productList = cartServiceDao.getProducts();
		//Check the no.of Records retrieved
		Assert.assertEquals(productList.size(), 7);
		
		//Check the values
		for(Product product: productList){
			String productId = product.getProductId();
			Assert.assertEquals(product.getQuantity(), 0);
			if(productId.equals("1001")) {
				Assert.assertEquals(product.getIsDiscounted(), 1);
				Assert.assertEquals(product.getPrice(), 50);
			} else if(productId.equals("1002")) {
				Assert.assertEquals(product.getIsDiscounted(), 1);
				Assert.assertEquals(product.getPrice(), 150);
			} else if(productId.equals("1003")) {
				Assert.assertEquals(product.getIsDiscounted(), 1);
				Assert.assertEquals(product.getPrice(), 200);
			} else if(productId.equals("1004")) {
				Assert.assertEquals(product.getIsDiscounted(), 1);
				Assert.assertEquals(product.getPrice(), 150);
			} else if(productId.equals("1005")) {
				Assert.assertEquals(product.getIsDiscounted(), 1);
				Assert.assertEquals(product.getPrice(), 100);
			} if(productId.equals("1006")) {
				Assert.assertEquals(product.getIsDiscounted(), 0);
				Assert.assertEquals(product.getPrice(), 250);
			} else if(productId.equals("1007")){
				Assert.assertEquals(product.getIsDiscounted(), 0);
				Assert.assertEquals(product.getPrice(), 100);
			} 
		}
	}
}
