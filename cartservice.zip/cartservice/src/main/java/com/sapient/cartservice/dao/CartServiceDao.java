package com.sapient.cartservice.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.inject.Singleton;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.sapient.cartservice.model.Product;

@Named
@Singleton
public class CartServiceDao {
	private EmbeddedDatabase dataSource;
	private final JdbcTemplate template;

	public CartServiceDao() {
		dataSource = new EmbeddedDatabaseBuilder()
				.setType(EmbeddedDatabaseType.HSQL)
				.addScript(
						"classpath:schema.sql")
				.addScript(
						"classpath:insert_product_detail.sql")
				.build();
		template = new JdbcTemplate(dataSource);
	}
	
	public List<Product> getProducts() {
		String selectQuery = "SELECT PRODUCT_ID, IS_DISCOUNTED, PRODUCT_NAME, PRICE FROM PRODUCT_DETAILS ORDER BY PRODUCT_ID";
		
		List<Product> productList = new ArrayList<Product>();

		try {
			productList = template.query(selectQuery, new ProductRowMapper());
		} catch (EmptyResultDataAccessException e) {
			throw new WebApplicationException(Response.status(404).build());
		}

		return productList;
	}

	public static class ProductRowMapper implements RowMapper<Product> {
		public Product mapRow(ResultSet rs, int row) throws SQLException {
			Product product = new Product(rs.getString(3), rs.getInt(4), rs.getInt(2), 0);
			product.setProductId(rs.getString(1));
			return product;
		}
	}	
	
}
