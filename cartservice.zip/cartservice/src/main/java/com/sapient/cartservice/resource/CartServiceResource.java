package com.sapient.cartservice.resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Scanner;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sapient.cartservice.dao.CartServiceDao;
import com.sapient.cartservice.model.Product;

@Named
@Singleton
@Path("/")
public class CartServiceResource {

	private CartServiceDao cartServiceDao;

	private List<Product> productList;

	@Inject
	public CartServiceResource(CartServiceDao cartServiceDao) {
		this.cartServiceDao = cartServiceDao;
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String showForm() throws IOException {
		this.productList = this.cartServiceDao.getProducts();
		
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("welcome.html");
		Scanner fileScanner = new Scanner(inputStream).useDelimiter("\\A");

		String welcomePage = fileScanner.hasNext() ? fileScanner.next() : "";

		int count = 1;
		for (Product product : productList) {
			welcomePage = welcomePage.concat("<tr><td>" + product.getProductName() + "</td>");
			welcomePage = welcomePage.concat("<td>" + product.getPrice() + "</td>");
			welcomePage = welcomePage
					.concat("<td><input type=\"number\" value= \"0\" required min=\"0\" name=\"quantity" + count
							+ "\"/></td></tr>");
			count++;
		}
		welcomePage = welcomePage
				.concat("</table><input type=\"submit\" value=\"Show Cart Price\" /></form></body></html>");

		return welcomePage;
	}

	@Path("order/cartdetails")
	@POST
	public String getDiscountDetails(@FormParam("quantity1") int quantity1, @FormParam("quantity2") int quantity2,
			@FormParam("quantity3") int quantity3, @FormParam("quantity4") int quantity4,
			@FormParam("quantity5") int quantity5, @FormParam("quantity6") int quantity6,
			@FormParam("quantity7") int quantity7) {

		int quantity[] = { quantity1, quantity2, quantity3, quantity4, quantity5, quantity6, quantity7 };

		int index = 0;
		for (Product product : productList) {
			product.setQuantity(quantity[index++]);
		}

		double discount = getDiscount(productList);

		setDiscountedPrice(productList, discount);

		String cartPage = "<html><body><h2>Final Cart Details</h2>";

		if (discount > 0)
			cartPage = cartPage.concat("<h3>You got " + (discount * 100) + "% discount on Harry Books!!</h3>");

		cartPage = cartPage.concat("<table><tr><th align=\"left\" width=\"200\">Book Name</th>");
		cartPage = cartPage.concat(
				"<th align=\"left\" width=\"100\">Actual Price</th><th align=\"left\" width=\"25\">Quantity</th>");
		cartPage = cartPage.concat("<th align=\"left\">Total Price</th></tr>");

		double totalCartPrice = 0.0;

		for (Product product : productList) {
			if (product.getQuantity() > 0) {
				cartPage = cartPage.concat("<tr><td>" + product.getProductName() + "</td>");
				cartPage = cartPage.concat("<td>" + product.getPrice() + "</td>");
				cartPage = cartPage.concat("<td>" + product.getQuantity() + "</td>");
				cartPage = cartPage.concat("<td>" + product.getDiscountedPrice() + "</td></tr>");
				totalCartPrice += product.getDiscountedPrice();
			}
			
		}

		cartPage = cartPage.concat("</table><h3> Total Cart Value: " + totalCartPrice + "</h3></body></html>");

		return cartPage;
	}

	public void setDiscountedPrice(List<Product> selectedList, double discount) {
		for (Product product : selectedList) {
			int price = product.getPrice();
			int quantity = product.getQuantity();
			if (product.getIsDiscounted() == 1) {
				product.setDiscountedPrice((price - (price * discount)) * quantity);
			} else
				product.setDiscountedPrice(price);
		}
	}

	public double getDiscount(List<Product> cartList) {

		double discount = 0;
		int noOfDiscountedProducts = 0;
		for (Product product : cartList) {
			if (product.getQuantity() > 0 && product.getIsDiscounted() == 1)
				noOfDiscountedProducts++;
		}
		switch (noOfDiscountedProducts) {
		case 2: {
			discount = 0.05;
			break;
		}
		case 3: {
			discount = 0.1;
			break;
		}
		case 4: {
			discount = 0.2;
			break;
		}
		case 5:
			discount = 0.25;
		}

		return discount;
	}
}
