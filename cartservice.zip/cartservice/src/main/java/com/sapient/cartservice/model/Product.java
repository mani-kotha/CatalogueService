package com.sapient.cartservice.model;

public class Product {

	private String productId;
	private String productName;
	private int price;
	private int isDiscounted;
	private int quantity;
	private double discountedPrice;
	
	public Product() {
		super();
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public Product(String productName, int price, int isDiscounted,int quantity){
		this.productName = productName;
		this.price = price;
		this.isDiscounted = isDiscounted;
		this.quantity = quantity;
	}

	public String getProductName() {
		return productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getIsDiscounted() {
		return isDiscounted;
	}

	public void setIsDiscounted(int isDiscounted) {
		this.isDiscounted = isDiscounted;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
}